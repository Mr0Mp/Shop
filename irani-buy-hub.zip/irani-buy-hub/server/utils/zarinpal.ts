import axios from "axios";

export const requestPayment = async (amount: number, description: string, callback: string) => {
  const res = await axios.post("https://api.zarinpal.com/pg/v4/payment/request.json", {
    merchant_id: process.env.ZARINPAL_MERCHANT_ID,
    amount,
    callback_url: callback,
    description
  });
  return res.data;
};

export const verifyPayment = async (authority: string, amount: number) => {
  const res = await axios.post("https://api.zarinpal.com/pg/v4/payment/verify.json", {
    merchant_id: process.env.ZARINPAL_MERCHANT_ID,
    amount,
    authority
  });
  return res.data;
};
