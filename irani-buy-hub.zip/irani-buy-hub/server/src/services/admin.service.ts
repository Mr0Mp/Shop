import prisma from "../utils/prisma";

export function getAllUsers() {
  return prisma.user.findMany({
    select: { id: true, name: true, email: true, role: true, createdAt: true }
  });
}

export function updateUserRole(userId: number, role: string) {
  return prisma.user.update({
    where: { id: userId },
    data: { role },
  });
}

export function deleteUser(id: number) {
  return prisma.user.delete({ where: { id } });
}

export function getAllProducts() {
  return prisma.product.findMany({
    include: { seller: true }
  });
}

export function deleteProduct(id: number) {
  return prisma.product.delete({ where: { id } });
}

export function getAllOrders() {
  return prisma.order.findMany({
    include: { user: true, product: true }
  });
}

export function updateOrderStatus(orderId: number, status: string) {
  return prisma.order.update({
    where: { id: orderId },
    data: { status }
  });
}
