import { Router } from "express";
const router = Router();

// سبد خرید کاربر
router.get("/", (req, res) => {
  res.json({ message: "Cart endpoint active" });
});

export default router;
