import jwt from 'jsonwebtoken';
export const sign = (payload:any)=> jwt.sign(payload, process.env.JWT_SECRET||'dev', { expiresIn: '7d' })
export const verify = (token:string)=> jwt.verify(token, process.env.JWT_SECRET||'dev')

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret";

export function signPayload(payload: object, opts?: jwt.SignOptions) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d", ...(opts || {}) });
}

export function verifyToken(token: string) {
  return jwt.verify(token, JWT_SECRET);
}